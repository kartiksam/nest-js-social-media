export enum StatusEnum {
    SUCCESS = 'SUCCESS',
    FAILED = 'FAILED'
}